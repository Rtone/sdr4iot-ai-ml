import _thread
import copy
import dataclasses
import datetime
import functools
from uuid import UUID
import re
from collections import deque
from typing import Optional, Any, List, Union, Callable, Dict

import dateutil
from click import ParamType
from dateutil.tz import tzlocal, tzutc, UTC


def normalize_depenv(deployment_environment: str) -> str:
    if deployment_environment == 'stable':
        return 'production'
    if deployment_environment == 'prod':
        return 'production'
    if deployment_environment == 'production':
        return 'production'
    if deployment_environment == 'staging':
        return 'staging'
    if deployment_environment == 'dev':
        return 'staging'
    if deployment_environment == 'development':
        return 'staging'
    return deployment_environment


class KeyValueParamType(ParamType):
    name = 'keyvalue'

    def convert(self, value, param, ctx):
        split = value.split('=')

        if len(split) != 2:
            self.fail("%s is not a valid key=value" % value, param, ctx)

        return (split[0], split[1])


class VolumeMappingParamType(ParamType):
    name = 'volumemapping'

    def convert(self, value, param, ctx):
        split = value.split(':')

        if len(split) > 3:
            self.fail("%s is not a valid volumemapping: expected 3 parts max, but got %d" % (value, len(split)),
                      param, ctx)

        host_src = container_dest = split[0]
        if len(split) > 1:
            container_dest = split[1]

        options = "rw"
        if len(split) > 2:
            options = split[2]

        return {"host_src": host_src, "container_dest": container_dest, "options": options}


def is_valid_email(email: Optional[str]) -> bool:
    if not email:
        return False
    email = str(email.strip())
    if '@' in email and '.' in email and len(email) >= 6:
        return True
    return False


ALLOWED_HOST_KEY_ALGOS = [
    # current secure versions according to https://github.com/jtesta/ssh-audit
    'ssh-ed25519-cert-v01@openssh.com,',
    'ssh-rsa-cert-v01@openssh.com,',
    'ssh-ed25519,',
    'ssh-rsa',
]


def is_valid_ssh_key(ssh_pub_key: Optional[str]) -> bool:
    if not ssh_pub_key:
        return False
    ssh_pub_key = str(ssh_pub_key.strip())
    key_parts = ssh_pub_key.split(' ')
    host_algo = key_parts[0]
    if host_algo in ALLOWED_HOST_KEY_ALGOS and len(key_parts) >= 2:
        return True
    return False


# example: 2020-03-04T23:33:45.1234+01:00
# example2: 2020-03-04T23:33:45.1234Z
# example3: 2020-03-04T23:33:45Z
RFC3339_PARSE_PATTERN_NOZULU = re.compile(
    r'([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])(.([0-9]+))?(([+-])([0-9][0-9]):00)')

RFC3339_PARSE_PATTERN_ZULU = re.compile(
    r'([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])(.([0-9]+))?Z')


def _fast_parse_rfc3339(text: str) -> Optional[datetime.datetime]:
    if (text.endswith('Z')):
        match = RFC3339_PARSE_PATTERN_ZULU.match(text)
        tzinfo = UTC
    else:
        match = RFC3339_PARSE_PATTERN_NOZULU.match(text)
        if match:
            assert match.group(10) in ('-', '+')
            sign = -1 if match.group(10) == '-' else 1
            tzhours = int(match.group(11))
            tzinfo = datetime.timezone(sign * datetime.timedelta(hours=tzhours, minutes=0))
        else:
            tzinfo = None
    if match:
        if match.group(7):
            msec_str = match.group(8)
            if len(msec_str) > 6:
                msec_str = msec_str[0:6]
            else:
                msec_str += '0' * (6 - len(msec_str))
            microsecond = int(msec_str)
        else:
            microsecond = 0
        return datetime.datetime(year=int(match.group(1)), month=int(match.group(2)), day=int(match.group(3)),
                          hour=int(match.group(4)), minute=int(match.group(5)), second=int(match.group(6)),
                          microsecond=microsecond,
                          tzinfo=tzinfo)
    else:
        return None

def parse_rfc3339(text: Optional[str]) -> datetime.datetime:
    if text is None:
        return None
    # this is a lot faster than dateutil.parser.parse,
    # but might fail for some edge cases, or non-RFC3999 ISO8601 dates
    res = _fast_parse_rfc3339(text)
    if res is None:
        # This can handle more than just RFC3339 (full ISO 8601), but that's OK
        res = dateutil.parser.parse(text)
    assert res is None or res.tzinfo is not None  # enforce timezone aware (non-naive) datetime
    return res


def dump_rfc3339(dt: Optional[datetime.datetime], zulu=True, no_milliseconds=True) -> str:
    if dt is None:
        return None
    assert isinstance(dt, datetime.datetime), 'not datetime.datetime but {}'.format(type(dt).__name__)
    assert dt.tzinfo is not None  # enforce timezone aware (non-naive) datetime
    if zulu:
        dt = dt.astimezone(tzutc())
    # else:
    #     dt = dt.astimezone(tzlocal())
    if no_milliseconds and dt.microsecond != 0:
        dt = dt.replace(microsecond=0)
    assert dt.tzinfo is not None  # enforce timezone aware (non-naive) datetime
    res = dt.isoformat()
    if res.endswith('+00:00'):
        res = res[:-6] + 'Z'
    return res


def datetime_now(zulu=False, no_milliseconds=True) -> datetime.datetime:
    res = datetime.datetime.now(datetime.timezone.utc)
    if not zulu:
        res = res.astimezone(tzlocal())
    if no_milliseconds:
        res = res.replace(microsecond=0)
    assert res.tzinfo is not None  # enforce timezone aware (non-naive) datetime
    return res


def _field_type_name(field_type) -> str:
    try:
        return field_type.__name__
    except AttributeError:
        return '{!r}'.format(field_type)


def dataclass_field_simple_type_check(obj: Any, field_name: str, required_type: type) -> None:
    """
    use dataclass_field_auto_type_check instead!
    :param obj:
    :param field_name:
    :param required_type:
    :return:
    """
    field_val = getattr(obj, field_name)
    if not isinstance(field_val, required_type):
        raise TypeError("{}.{} must be {}, not {}".
                        format(type(obj).__name__, field_name, required_type.__name__, type(field_val).__name__))


def dataclass_field_type_check(obj: Any, field_name: str) -> None:
    field = next(field for field in dataclasses.fields(obj) if field.name == field_name)
    field_val = getattr(obj, field_name)
    if not isinstance(field_val, field.type):
        raise TypeError("{}.{} must be {}, not {}".
                        format(type(obj).__name__, field_name, _field_type_name(field.type), type(field_val).__name__))


def dataclass_field_datetime_check(obj: Any, field_name: str) -> None:
    field = next(field for field in dataclasses.fields(obj) if field.name == field_name)
    field_val = getattr(obj, field_name)
    assert field.type == datetime.datetime
    if not isinstance(field_val, datetime.datetime):
        raise TypeError("{}.{} must be datetime.datetime, not {}".
                        format(type(obj).__name__, field_name, type(field_val).__name__))
    if field_val.tzinfo is None:
        raise TypeError("{}.{} must be non-naive datetime.datetime, but it is naive!".
                        format(type(obj).__name__, field_name))


def dataclass_field_listof_check(obj: Any, field_name: str, list_item_type: type) -> None:
    field_val = getattr(obj, field_name)
    if not isinstance(field_val, list):
        raise TypeError("{}.{} must be {}, not {}".
                        format(type(obj).__name__, field_name, list.__name__, type(field_val).__name__))
    for item in field_val:
        if not isinstance(item, list_item_type):
            raise TypeError("{}.{} items must be {}, not {}".
                            format(type(obj).__name__, field_name, list_item_type.__name__, type(item).__name__))


def dataclass_field_optional_check(obj: Any, field_name: str, optional_of_type: type) -> None:
    field_val = getattr(obj, field_name)
    if field_val is None:
        return
    if not isinstance(field_val, optional_of_type):
        raise TypeError("{}.{} must be Optional[{}], not Optional[{}]".
                        format(type(obj).__name__, field_name, optional_of_type.__name__, type(field_val).__name__))


def dataclass_field_optional_datetime_check(obj: Any, field_name: str) -> None:
    field_val = getattr(obj, field_name)
    if field_val is None:
        return
    if not isinstance(field_val, datetime.datetime):
        raise TypeError("{}.{} must be Optional[datetime.datetime], not Optional[{}]".
                        format(type(obj).__name__, field_name, type(field_val).__name__))
    if field_val.tzinfo is None:
        raise TypeError("{}.{} must be None or a non-naive datetime.datetime, but it is naive!".
                        format(type(obj).__name__, field_name))


def dataclass_field_optional_union_check(obj: Any, field_name: str, *args: type) -> None:
    field_val = getattr(obj, field_name)
    if field_val is None:
        return
    for optional_of_type in args:
        if isinstance(field_val, optional_of_type):
            return
    raise TypeError("{}.{} must be Optional[{}], not Optional[{}]".
                    format(type(obj).__name__,
                           field_name,
                           [optional_of_type.__name__ for optional_of_type in args],
                           type(field_val).__name__)
                    )


def dataclass_field_union_check(obj: Any, field_name: str, *args: type) -> None:
    field_val = getattr(obj, field_name)
    for acceptable_type in args:
        if isinstance(field_val, acceptable_type):
            return
    raise TypeError("{}.{} must be one of {}, not {}".
                    format(type(obj).__name__,
                           field_name,
                           [acceptable_type.__name__ for acceptable_type in args],
                           type(field_val).__name__)
                    )


def _check_list_type_elements_helper(obj, field_name: str, list_val: Any, list_element_type):
    for i in list(list_val):
        if not isinstance(i, list_element_type):
            raise TypeError("{}.{} must contain list of {}, but the list has a {}".format(
                type(obj).__name__, field_name,
                _field_type_name(list_element_type), type(i).__name__))
        if issubclass(list_element_type, datetime.datetime) and i.tzinfo is None:
            raise TypeError("{}.{} must contain list of non-naive {}, but the list has a naive {}".format(
                type(obj).__name__, field_name,
                _field_type_name(list_element_type), type(i).__name__))


def _check_dict_type_value_helper(obj, field_name: str, dict_val: Any, dict_value_type):
    for i in dict_val.values():
        if not isinstance(i, dict_value_type):
            raise TypeError("{}.{} must contain dict with values of {}, but the value is a {}".format(
                type(obj).__name__, field_name,
                _field_type_name(dict_value_type), type(i).__name__))
        if issubclass(dict_value_type, datetime.datetime) and i.tzinfo is None:
            raise TypeError("{}.{} must contain list of non-naive {}, but the list has a naive {}".format(
                type(obj).__name__, field_name,
                _field_type_name(dict_value_type), type(i).__name__))


def _dataclass_field_auto_type_check(obj, field_name, field_val, field_type):
    # Note: this gets angry about naive datetime, and won't allow them

    # Union also cover Optional[X], which is Union[X, NoneType]
    if hasattr(field_type, '__origin__') and field_type.__origin__ is Union:
        for allowed_type in field_type.__args__:
            if hasattr(allowed_type, '__origin__') and allowed_type.__origin__ is list:
                assert hasattr(allowed_type, '__args__')
                if isinstance(field_val, list):
                    list_element_type = allowed_type.__args__[0]
                    _check_list_type_elements_helper(obj, field_name, field_val, list_element_type)
                    return
            else:
                if isinstance(field_val, allowed_type):
                    if issubclass(allowed_type, datetime.datetime) and field_val.tzinfo is None:
                        raise TypeError("{}.{} must be {}, and it is a {}, but a naive one".format(
                            type(obj).__name__, field_name,
                            _field_type_name(allowed_type), type(field_val).__name__))
                    return
        raise TypeError("{}.{} must be one of {}, not {} ({!r} {!r})".format(
            type(obj).__name__, field_name,
            [_field_type_name(t) for t in field_type.__args__], type(field_val).__name__,
            field_type.__args__, type(field_val)))

    if hasattr(field_type, '__origin__') and field_type.__origin__ is list:
        list_element_type = field_type.__args__[0]
        if not isinstance(field_val, list):
            raise TypeError("{}.{} must be list, not {}".format(
                type(obj).__name__, field_name, type(field_val).__name__))
        _check_list_type_elements_helper(obj, field_name, field_val, list_element_type)
        return

    if hasattr(field_type, '__origin__') and field_type.__origin__ is dict:
        if not field_type.__args__:
            field_type = dict
            # no return, just check if it's a generic dict
        else:
            dict_key_type = field_type.__args__[0]
            dict_value_type = field_type.__args__[1]
            if dict_key_type is not str:
                raise NotImplementedError("deep Dict type check with non-str keys is not implemented")
            if not isinstance(field_val, dict):
                raise TypeError("{}.{} must be dict, not {}".format(
                    type(obj).__name__, field_name, type(field_val).__name__))
            _check_dict_type_value_helper(obj, field_name, field_val, dict_value_type)
            return

    if not isinstance(field_val, field_type):
        raise TypeError("{}.{} must be {}, not {}".format(
            type(obj).__name__, field_name,
            _field_type_name(field_type), type(field_val).__name__))

    if issubclass(field_type, datetime.datetime) and field_val.tzinfo is None:
        raise TypeError("{}.{} must be non-nave {}, not is it a naive {}".format(
            type(obj).__name__, field_name,
            _field_type_name(field_type), type(field_val).__name__))


def dataclass_field_auto_type_check(obj, field_name):
    field = next(field for field in dataclasses.fields(obj) if field.name == field_name)
    field_val = getattr(obj, field_name)
    _dataclass_field_auto_type_check(obj, field_name, field_val, field.type)


def dataclass_fields_type_check(
        obj: Any,
        field_names_included: Optional[List[str]] = None,
        field_names_excluded: Optional[List[str]] = None) -> None:
    for field in dataclasses.fields(obj):
        if (not field_names_included or field.name in field_names_included) and \
                not (field_names_excluded and field.name in field_names_excluded):
            field_val = getattr(obj, field.name)
            _dataclass_field_auto_type_check(obj, field.name, field_val, field.type)
            # if not isinstance(field_val, field.type):
            #     raise TypeError("{}.{} must be {}, not {}".format(type(obj).__name__, field.name, _field_type_name(field.type), type(field_val).__name__))


def _add_auto_type_check_to_class(cls,
                                  field_names_included: Optional[List[str]] = None,
                                  field_names_excluded: Optional[List[str]] = None):

    has_post_init = hasattr(cls, '__post_init__')

    if has_post_init:
        # print('adding auto type check to {!r} (adding to __post_init__)'.format(cls))
        old_post_init = cls.__post_init__

        def updated_post_init(self, *args, **kwargs):
            old_post_init(self, *args, **kwargs)
            dataclass_fields_type_check(self, field_names_included, field_names_excluded)
        cls.__post_init__ = updated_post_init
    else:
        # print('adding auto type check to {!r} (new __post_init__)'.format(cls))

        def new_post_init(self):
            dataclass_fields_type_check(self, field_names_included, field_names_excluded)
        cls.__post_init__ = new_post_init

    return cls


def _add_copy_method_to_class(cls):
    def make_copy(self):
        return copy.deepcopy(self)
        ## original method used dataclasses_json:
        ## one test fails due to strange, strange issue with _get_type_hints_cached in dataclasses_json core
        # selfclass = self.__class__
        # print('\n      cls={!r}\nselfclass={!r}'.format(cls, selfclass))
        # # Hack: This can fail, due to some strange cache issue, the next line should init the cache:
        # fields = dataclasses.fields(selfclass)
        # for field in fields:
        #     field_val = getattr(self, field.name)
        #     print('Field {} val={!r} type={!r} typehint={!r}'.format(
        #         field.name,
        #         field_val,
        #         field.type,
        #         get_type_hints(cls)[field.name]
        #     ))
        # return selfclass.from_dict(self.to_dict())

    cls.make_copy = make_copy
    return cls


def dataclass_auto_type_check(_cls=None, *,
                              field_names_included: Optional[List[str]] = None,
                              field_names_excluded: Optional[List[str]] = None):
    """
        This assumes @dataclass !  (but not @dataclass_json or @dataclass_dict_convert)
        It must be placed both BELOW @dataclass !   (otherwise, it won't work if you have no __post_init__ yet!!!)

    this has complex logic to allow decorating with both:
          @dataclass_auto_type_check
          @dataclass_auto_type_check(field_names_excluded=['aFieldName'])

    example:
          @dataclass
          @dataclass_auto_type_check(field_names_excluded=['field_a'])
          class X:
             field_a: int
             ...
    """

    def wrap(cls):
        return _add_auto_type_check_to_class(cls, field_names_included, field_names_excluded)

    if _cls is None:
        return wrap
    return wrap(_cls)


def dataclass_copy_method(_cls=None):
    """
    This assumes @dataclass
    # old, but not anymore: This assumes @dataclass_json !
    It works both below and above @dataclass_json/@dataclass_dict_convert and @dataclass

    this has complex logic to allow decorating with both:
      @dataclass_copy_method
      @dataclass_copy_method()

    example:
      @dataclass_copy_method
      @dataclass_dict_convert
      @dataclass
      class X:
         field_a: int
         ...
    """

    def wrap(cls):
        return _add_copy_method_to_class(cls)

    if _cls is None:
        return wrap
    return wrap(_cls)


# def _add_dataclass_json_hack_nested_from_dict(cls):
#     orig_from_dict = cls.from_dict
#     all_fields = dataclasses.fields(cls)
#     letter_case = cls.dataclass_json_config.get('letter_case', lambda s: s) \
#         if cls.dataclass_json_config \
#         else lambda s: s
#
#     def corrected_from_dict(cls2, kvs, *, infer_missing=False):
#         for field in all_fields:
#             dict_fieldname = letter_case(field.name)
#             field_value = kvs.get(dict_fieldname)
#             if dataclasses.is_dataclass(field.type):
#                 if field_value and isinstance(field_value, dict) and not dataclasses.is_dataclass(field_value):
#                     kvs[dict_fieldname] = field.type.from_dict(field_value)
#         return orig_from_dict(kvs=kvs, infer_missing=infer_missing)
#
#     cls.from_dict = classmethod(corrected_from_dict)
#     return cls
#
#
# def dataclass_json_hack_nested_from_dict(_cls=None):
#     """
#     For dataclass_json_wrap_in_list and dataclass_json_list_str_or_str to work,
#     from_dict must be called recursivly, but dataclass_json does NOT do this.
#     It recurses it's own code, not the oerwritten code.
#
#     this has complex logic to allow decorating with both:
#       @dataclass_json_hack_nested_from_dict
#       @dataclass_json_hack_nested_from_dict()
#
#     @dataclass_json_hack_nested_from_dict should be placed above @dataclass_json to auto-fix this.
#
#     Example:
#        @dataclass_json_hack_nested_from_dict
#        @dataclass_json
#        @dataclass
#        class X:
#          field_a: SomeDataClass  # Some dataclass using @dataclass_json_wrap_in_list and dataclass_json
#          ...
#     """
#     def wrap(cls):
#         return _add_dataclass_json_hack_nested_from_dict(cls)
#
#     if _cls is None:
#         return wrap
#     return wrap(_cls)
#
#
# def dataclass_json_wrap_in_list(*, fields: List[str]):
#     """
#     Assumes the listed fields can be a list, OR a single item.
#     In the later case, wraps the item in a list.
#
#     this is needed because dataclass_json otherwise accepts singleton strings as list of str (list of letters)
#
#     :param fields:
#     :return:
#     """
#     def wrap(cls):
#         orig_from_dict = cls.from_dict
#         all_fields = dataclasses.fields(cls)
#         letter_case = cls.dataclass_json_config.get('letter_case', lambda s: s) \
#             if cls.dataclass_json_config \
#             else lambda s: s
#
#         def corrected_from_dict(cls2, kvs, *, infer_missing=False):
#             for field_name in fields:
#                 dict_fieldname = letter_case(field_name)
#                 field_type = None
#                 for field in all_fields:
#                     if field.name == field_name:
#                         field_type = field.type
#                 assert field_type
#                 field_val = kvs.get(dict_fieldname)
#                 if hasattr(field_type, '__origin__') and field_type.__origin__ is list:
#                     list_element_type = field_type.__args__[0]
#                     if field_val and ((not isinstance(field_val, list)) or isinstance(field_val, list_element_type)):
#                     # if field_val and (not isinstance(field_val, list)) and isinstance(field_val, list_element_type):
#                         kvs[dict_fieldname] = [field_val]
#                 else:
#                     raise TypeError('dataclass_json_wrap_in_list only works on list fields, '
#                                     'not on field of type {!r}'.format(field_type))
#             return orig_from_dict(kvs=kvs, infer_missing=infer_missing)
#         cls.from_dict = classmethod(corrected_from_dict)
#         return cls
#     return wrap
#
#
# def dataclass_json_list_str_or_str(*, fields: List[str]):
#     """
#     Assumes the listed fields can be a list of str, OR a single str.
#     this is needed because dataclass_json otherwise accepts singleton strings as list of str (list of letters)
#
#     :param fields:
#     :return:
#     """
#     def wrap(cls):
#         orig_from_dict = cls.from_dict
#         all_fields = dataclasses.fields(cls)
#         letter_case = cls.dataclass_json_config.get('letter_case', lambda s: s) \
#             if cls.dataclass_json_config \
#             else lambda s: s
#
#         def corrected_from_dict(cls2, kvs, *, infer_missing=False):
#             for field_name in fields:
#                 dict_fieldname = letter_case(field_name)
#                 field_type = None
#                 for field in all_fields:
#                     if field.name == field_name:
#                         field_type = field.type
#                 assert field_type
#                 field_val = kvs.get(dict_fieldname)
#                 if hasattr(field_type, '__origin__') and field_type.__origin__ is list:
#                     list_element_type = field_type.__args__[0]
#                     if field_val and (not isinstance(field_val, list) or isinstance(field_val, list_element_type)):
#                         kvs[dict_fieldname] = [field_val]
#                 else:
#                     raise TypeError('dataclass_json_wrap_in_list only works on list fields, '
#                                     'not on field of type {!r}'.format(field_type))
#             return orig_from_dict(kvs=kvs, infer_missing=infer_missing)
#         cls.from_dict = classmethod(corrected_from_dict)
#         return cls
#     return wrap
#
#
# def dataclass_json_pre_modify_dict_field(*, modifier_by_fieldname: Dict[str, Callable]):
#     def wrap(cls):
#         orig_from_dict = cls.from_dict
#         letter_case = cls.dataclass_json_config.get('letter_case', lambda s: s) \
#             if cls.dataclass_json_config \
#             else lambda s: s
#
#         def modified_from_dict(cls, kvs, *, infer_missing=False):
#             for field_name, modifier in modifier_by_fieldname.items():
#                 dict_fieldname = letter_case(field_name)
#                 field_type = None
#                 orig_field_val = kvs.get(dict_fieldname)
#                 modified_field_val = modifier(orig_field_val)
#                 if orig_field_val is not None or modified_field_val is not None:
#                     if modified_field_val is not None:
#                         kvs[dict_fieldname] = modified_field_val
#                     else:
#                         del kvs[dict_fieldname]
#             return orig_from_dict(kvs, infer_missing=infer_missing)
#         cls.from_dict = classmethod(modified_from_dict)
#         return cls
#     return wrap
#
#
# def dataclass_json_pre_modify_dict(*, modifier: Callable[[Dict], Dict]):
#     def wrap(cls):
#         orig_from_dict = cls.from_dict
#
#         def modified_from_dict(cls, kvs, *, infer_missing=False):
#             return orig_from_dict(modifier(kvs), infer_missing=infer_missing)
#         cls.from_dict = classmethod(modified_from_dict)
#         return cls
#     return wrap


def _add_dataclass_multiline_repr_method_to_class(cls):
    # recursive_repr function is based on "recursive_repr" function in reprlib and dataclasses _repr_fn
    # This version doesn't use helper functions

    repr_running = set()

    def dataclasses_multiline_repr_helper(self):
        key = _thread.get_ident()
        if key in repr_running:
            return '...'
        repr_running.add(key)
        try:
            all_fields = dataclasses.fields(self)
            field_repr_list = []
            for field in all_fields:
                field_val = getattr(self, field.name)
                field_repr = f"   {field.name}={field_val!r}"
                field_repr = field_repr.replace('\n', '\n   ')
                field_repr_list.append(field_repr)
            fields_repr = '\n' + ',\n'.join(field_repr_list)
            result = f"{self.__class__.__qualname__}({fields_repr})"
        finally:
            repr_running.discard(key)
        return result

    cls.__repr__ = dataclasses_multiline_repr_helper
    return cls


def dataclass_multiline_repr(_cls=None):
    """
    Make repr use newlines between fields, for much more readable output.

    This assumes @dataclass
    It works both below and above @dataclass, but if above @dataclass, you need: @dataclass(repr=False)

    this has complex logic to allow decorating with both:
      @dataclass_multiline_repr
      @dataclass_multiline_repr()

    example:
      @dataclass_multiline_repr
      @dataclass(repr=False)
      class X:
         field_a: int
         ...

    or same:
      @dataclass
      @dataclass_multiline_repr
      class X:
         field_a: int
         ...

    """
    def wrap(cls):
        return _add_dataclass_multiline_repr_method_to_class(cls)

    if _cls is None:
        return wrap
    return wrap(_cls)


def any_to_opt_bool(value: Any, default: Optional[bool] = None) -> Optional[bool]:
    if value is None:
        return default
    if value == 1:
        return True
    if value == 0:
        return False
    if str(value).lower() in ['true', 't', '1', 'yes']:
        return True
    if str(value).lower() in ['false', 'f', '0', 'no']:
        return False
    return default


def any_to_bool(value: Any, default: Optional[bool] = None) -> bool:
    res = any_to_opt_bool(value, default)
    if res is not None:
        return res
    if default is None:
        raise 'Could not convert "{}" to boolean value'.format(value)
    return default


def deep_update_dict(target: dict, extra: dict) -> dict:
    """
    Deep update by adding all keys (nested) of extra to target.
    Nested arrays are copied from extra to target with copy.deepcopy(), so no deep_update is done on them!

    Notes:
       - this deeply modifies target, so make sure you first copy.deepcopy it if needed!
       - you can't remove keys from target with this, only add them
       - type conflicts between values of target and extra are handled by extra overriding target

    :param target: the dict that should be updated deeply
    :param extra: extra keys to be added (nested)
    :return: target
    """

    # deque to avoid recursion
    jobs = deque()
    jobs.append( (target, extra) )

    while len(jobs) > 0:
        job_target, job_extra = jobs.popleft()

        for key,extra_value in job_extra.items():
            if isinstance(extra_value, dict):
                if key in job_target and isinstance(job_target[key], dict):
                    jobs.append( (job_target[key], extra_value) )
                else:
                    job_target[key] = copy.deepcopy(extra_value)
            else:
                job_target[key] = extra_value

    return target


def duration_string_to_seconds(duration: str) -> Optional[int]:
    if not duration:
        return None
    match = re.match(r'^([0-9.]+) *([a-zA-Z]+)$', duration)
    if not match:
        return None

    num = float(match.group(1)) if '.' in match.group(1) else int(match.group(1))
    unit = match.group(2).lower()
    if unit == 'h' or unit == 'hour' or unit == 'hours':
        return int(num * 60 * 60)
    elif unit == 'm' or unit == 'min' or unit == 'mins' or unit == 'minute' or unit == 'minutes':
        return int(num * 60)
    elif unit == 's' or unit == 'sec' or unit == 'secs' or unit == 'second' or unit == 'seconds':
        return int(num)
    elif unit == 'day' or unit == 'days':
        return int(num * 60 * 60 * 24)
    elif unit == 'week' or unit == 'weeks':
        return int(num * 60 * 60 * 24 * 7)
    else:
        return None
    # Impossible to support because not fixed length: month, year, ...


def strip_null_from_json_dict(json_dict: dict, *, strip_empty_dict: bool = False, strip_empty_list: bool = False):
    """
    Strip null values from dicts, also stripping empty dicts and list values if requested.
    Doesn't look inside lists, so doesn't:
       - Strip dicts inside lists.
       - Remove empty dicts inside lists.

    (recursive-less implementation, which adds a bit of complexity.)

    :param json_dict:
    :param strip_empty_dict:
    :param strip_empty_list:
    :return:
    """
    res = copy.deepcopy(json_dict)

    todo = deque()
    todo.append((res, []))

    while len(todo) > 0 :
        current, parents = todo.popleft()

        empty = []
        for key, value in current.items():
            if value is None:
                empty.append(key)
            elif isinstance(value, dict):
                if len(value) > 0:
                    todo.append((value, parents + [current]))
                elif strip_empty_dict:
                    empty.append(key)
            elif isinstance(value, list):
                if len(value) == 0 and strip_empty_list:
                    empty.append(key)
        for key in empty:
            del current[key]
        if len(current) == 0 and parents and strip_empty_dict:
            parent_parents = list(parents)
            parent = parent_parents.pop()
            todo.append((parent, parent_parents))
    return res


# Not best idea: need to differentiate between key not present and bool parse failure
# def any_dictvalue_to_opt_bool(d: dict, key: Any, default: Optional[bool] = None) -> Optional[bool]:
#     value = d.get(key, None)
#     return any_to_opt_bool(value, default)
#
#
# def any_dictvalue_to_bool(d: dict, key: Any, default: Optional[bool] = None) -> bool:
#     res = any_dictvalue_to_opt_bool(d, key, default)
#     if res is not None:
#         return res
#     if default is None:
#         raise 'Could not convert "{}" to boolean value'.format(value)
#     return default


def is_valid_uuid4(uuid_str: str) -> bool:
    try:
        uuid_obj = UUID(uuid_str, version=4)
    except ValueError:
        return False

    return str(uuid_obj) == uuid_str


def is_valid_uuid(uuid_str: str) -> bool:
    try:
        uuid_obj = UUID(uuid_str)
    except ValueError:
        return False

    recontructed_uuid_str = str(uuid_obj)
    assert len(recontructed_uuid_str) == 36, "is_valid_uuid({}) uuid_obj={} recontructed_uuid_str={} len={}"\
        .format(uuid_str, uuid_obj, recontructed_uuid_str, len(recontructed_uuid_str) == 36)
    return recontructed_uuid_str.lower() == uuid_str.lower()
