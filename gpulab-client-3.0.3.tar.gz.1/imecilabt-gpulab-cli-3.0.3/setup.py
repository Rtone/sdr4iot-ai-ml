
from setuptools import setup, find_packages

setup(
    name="imecilabt-gpulab-cli",
    version="3.0.3",
    # Make sure to also update version number in imecilabt/gpulab/cli/__main__.py  (three times!)

    description="GPULab CLI",
    long_description="GPULab CLI for submitting jobs to an GPULab instance",

    url="https://gpulab.ilabt.imec.be",

    author="Thijs Walcarius",
    author_email="thijs.walcarius@ugent.be",

    packages=["imecilabt.gpulab.cli", "imecilabt.gpulab.model", "imecilabt.gpulab.util",
              # "sentry-sdk==0.14.4"  # not yet
              ],


#requests 2.18.0 is required for "with session.get() as r:"  ("Response is now a context manager")
#         2.18.4 is what works, so why not require it
#click 6.7 is what works, so why not require it

# Python version requirement:
#     At least python 3.4 was required previously (not sure for which feature, but < 3.4 will certainly fail)
#     but now, gpulab-common uses dataclasses, so at least python 3.7 is required
#        (python 3.7.0 was released June 27, 2018)
#        (python 3.7 is available from ubuntu 19.04 Disco Dingo, released April 18, 2019)
#            (the deadsnakes ppa can be used for earlier ubuntu's)
#        (python 3.7 is available from debian 10.0 buster, released July 6th, 2019)
#        + there's always https://github.com/pyenv/pyenv

    install_requires=["requests>=2.18.4", "click>=6.7", "timestamp",
                      "python-dateutil", "stringcase",
                      "cryptography", "timestamp", "pyyaml"],
    # python_requires='>=3.4',
    python_requires='>=3.7',

    entry_points={
        'console_scripts': [
            'gpulab-cli=imecilabt.gpulab.cli.__main__:main',
        ],
    },
    zip_safe=False, # Zipped eggs don't play nicely with namespace packaging, and may be implicitly installed by commands like python setup.py install. To prevent this, it is recommended that you set zip_safe=False in setup.py

)


